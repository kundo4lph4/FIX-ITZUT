CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    number VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'student', 
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE reports (
    id SERIAL PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    location VARCHAR(150) NOT NULL,
    image_url VARCHAR(255),
    status VARCHAR(50) DEFAULT 'Pending',
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- Insert a default admin account for testing (Password: admin123)
INSERT INTO users (name , email, password, role) 
VALUES ('Admin User', 'admin@zut.ac.zm', '$2a$10$X8X8X8X8X8X8X8X8X8X8X8X8X8X8X8X8X8X8X8X8X8X8X8X8X8X8X', 'admin');
-- Note: In a real app, hash the password properly. For this demo, register a new admin via the UI or use bcrypt to hash 'admin123' and replace the hash above